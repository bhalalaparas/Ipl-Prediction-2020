from django.apps import AppConfig


class IplConfig(AppConfig):
    name = 'ipl'
